
message='<hr>这一行是由2.js 输出的结果';
document.writeln(message);

