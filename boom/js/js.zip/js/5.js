message='<hr>这一行是由5.js 输出的结果';
document.writeln(message);
